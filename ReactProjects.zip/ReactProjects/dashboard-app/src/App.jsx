import "./App.css";

import Welcome from "./components/Welcome.jsx";
import CourseDetails from "./components/CourseDetails.jsx";
import Message from "./components/Message.jsx";

function App() {
  return (
    <div className="dashboard">
      <h1>Welcome to Startup Dashboard</h1>

      <Welcome />
      <CourseDetails />
      <Message />
    </div>
  );
}

export default App;
