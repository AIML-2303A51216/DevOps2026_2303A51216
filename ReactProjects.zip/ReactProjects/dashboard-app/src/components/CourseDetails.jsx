function CourseDetails() {
  return (
    <div className="card">
      <h2>Course Details</h2>
      <p>Course Name: React Development</p>
      <p>Duration: 3 Months</p>
      <p>Mode: Online</p>
    </div>
  );
}

export default CourseDetails;
